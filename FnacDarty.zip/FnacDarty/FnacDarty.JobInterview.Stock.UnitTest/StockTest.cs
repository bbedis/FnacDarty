using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FnacDarty.JobInterview.Stock.UnitTest
{
    [TestClass]
    public class StockTest
    {
        IRepository _sut;

        public StockTest()
        {
            _sut = new Repository();

            _sut.Add(new Product { Id = "EAN00001" }, 10, DateTime.Parse("01/01/2020"), "Achat N°1");
            _sut.Add(new Product { Id = "EAN00002" }, 10, DateTime.Parse("01/01/2020"), "Achat N°2");
            _sut.Add(new Product { Id = "EAN00003" }, 10, DateTime.Parse("01/01/2020"), "Achat N°3");

            _sut.Add(new Product { Id = "EAN00001" }, -3, DateTime.Parse("02/01/2020"), "Cmd N°1");
            _sut.Add(new Product { Id = "EAN00002" }, -3, DateTime.Parse("02/01/2020"), "Cmd N°1");
            _sut.Add(new Product { Id = "EAN00003" }, -3, DateTime.Parse("02/01/2020"), "Cmd N°1");

            _sut.Add(new Product { Id = "EAN00001" }, -1, DateTime.Parse("03/01/2020"), "Cmd N°2");
            _sut.Add(new Product { Id = "EAN00002" }, -10, DateTime.Parse("03/01/2020"), "Cmd N°2");

            _sut.Add(new Product { Id = "EAN00002" }, 1, DateTime.Parse("04/01/2020"), "inventaire");


        }

        [TestMethod]
        public void get_stock_first_day()
        {
            var EAN00001 = _sut.GetStock(new Product { Id = "EAN00001" }, DateTime.Parse("01/01/2020"));
            var EAN00002 = _sut.GetStock(new Product { Id = "EAN00002" }, DateTime.Parse("01/01/2020"));
            var EAN00003 = _sut.GetStock(new Product { Id = "EAN00003" }, DateTime.Parse("01/01/2020"));
            
            Assert.AreEqual(10, EAN00001);
            Assert.AreEqual(10, EAN00002);
            Assert.AreEqual(10, EAN00003);




        }

        [TestMethod]
        public void get_stock_second_day()
        {
            var EAN00001 = _sut.GetStock(new Product { Id = "EAN00001" }, DateTime.Parse("02/01/2020"));
            var EAN00002 = _sut.GetStock(new Product { Id = "EAN00002" }, DateTime.Parse("02/01/2020"));
            var EAN00003 = _sut.GetStock(new Product { Id = "EAN00003" }, DateTime.Parse("02/01/2020"));

            Assert.AreEqual(7, EAN00001);
            Assert.AreEqual(7, EAN00002);
            Assert.AreEqual(7, EAN00003);

             EAN00001 = _sut.GetVariation(new Product { Id = "EAN00001" }, DateTime.Parse("02/01/2020"), DateTime.Parse("01/01/2020"));
             EAN00002 = _sut.GetVariation(new Product { Id = "EAN00002" }, DateTime.Parse("02/01/2020"), DateTime.Parse("01/01/2020"));
             EAN00003 = _sut.GetVariation(new Product { Id = "EAN00003" }, DateTime.Parse("02/01/2020"), DateTime.Parse("01/01/2020"));

            Assert.AreEqual(-3, EAN00001);
            Assert.AreEqual(-3, EAN00002);
            Assert.AreEqual(-3, EAN00003);

        }



        [TestMethod]
        public void get_stock_third_day()
        {
            var EAN00001 = _sut.GetStock(new Product { Id = "EAN00001" }, DateTime.Parse("03/01/2020"));
            var EAN00002 = _sut.GetStock(new Product { Id = "EAN00002" }, DateTime.Parse("03/01/2020"));
            var EAN00003 = _sut.GetStock(new Product { Id = "EAN00003" }, DateTime.Parse("03/01/2020"));

            Assert.AreEqual(6, EAN00001);
            Assert.AreEqual(0, EAN00002);
            Assert.AreEqual(7, EAN00003);

            EAN00001 = _sut.GetVariation(new Product { Id = "EAN00001" }, DateTime.Parse("03/01/2020"), DateTime.Parse("01/01/2020"));
            EAN00002 = _sut.GetVariation(new Product { Id = "EAN00002" }, DateTime.Parse("03/01/2020"), DateTime.Parse("01/01/2020"));
            EAN00003 = _sut.GetVariation(new Product { Id = "EAN00003" }, DateTime.Parse("03/01/2020"), DateTime.Parse("01/01/2020"));

            Assert.AreEqual(-4, EAN00001);
            Assert.AreEqual(-10, EAN00002);
            Assert.AreEqual(-3, EAN00003);

        }

        [TestMethod]
        public void get_stock_forth_day()
        {
            var EAN00001 = _sut.GetStock(new Product { Id = "EAN00001" }, DateTime.Parse("04/01/2020"));
            var EAN00002 = _sut.GetStock(new Product { Id = "EAN00002" }, DateTime.Parse("04/01/2020"));
            var EAN00003 = _sut.GetStock(new Product { Id = "EAN00003" }, DateTime.Parse("04/01/2020"));

            Assert.AreEqual(6, EAN00001);
            Assert.AreEqual(1, EAN00002);
            Assert.AreEqual(7, EAN00003);

            EAN00001 = _sut.GetVariation(new Product { Id = "EAN00001" }, DateTime.Parse("04/01/2020"), DateTime.Parse("01/01/2020"));
            EAN00002 = _sut.GetVariation(new Product { Id = "EAN00002" }, DateTime.Parse("04/01/2020"), DateTime.Parse("01/01/2020"));
            EAN00003 = _sut.GetVariation(new Product { Id = "EAN00003" }, DateTime.Parse("04/01/2020"), DateTime.Parse("01/01/2020"));

            Assert.AreEqual(-4, EAN00001);
            Assert.AreEqual(-9, EAN00002);
            Assert.AreEqual(-3, EAN00003);

        }
    }
}
