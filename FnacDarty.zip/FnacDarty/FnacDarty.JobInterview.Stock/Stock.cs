﻿using System.Collections.Generic;

namespace FnacDarty.JobInterview.Stock
{
    public class Stock
    {
        public List<(Product p, int quantity)> Products { get; set; } = new List<(Product p, int quantity)>();
        public List<Movement> Movements { get; set; } = new List<Movement>();
        
    }
}
