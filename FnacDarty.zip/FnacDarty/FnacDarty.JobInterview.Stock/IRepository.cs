﻿using System;
using System.Collections.Generic;

namespace FnacDarty.JobInterview.Stock
{
    public interface IRepository
    {
        void Add(Product p, int quantity, DateTime date, string label);
        void SellProduct(Product p, int quantity, DateTime date, string label);
        void Add(List<(Product p, int quantity)> movements, DateTime date, string label);
        int GetStock(Product p, DateTime date);
        int GetVariation(Product p, DateTime d1, DateTime d2);
        int GetStock(Product p);
        List<(Product p, int quantity)> GetProductInStock();
        int GetAvailableProductsCountInStock();
        void SetStock(Product p, int quantity);
    }
}
