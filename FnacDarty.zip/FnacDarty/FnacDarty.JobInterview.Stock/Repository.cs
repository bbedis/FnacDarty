﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FnacDarty.JobInterview.Stock
{
    public class Repository : IRepository
    {
        private Stock _stock = new Stock();

        public void Add(Product p, int quantity, DateTime date, string label)
        {
            var move = new Movement { Date = date, Label = label, Products = { (p, quantity) } };
            _stock.Movements.Add(move);

            var product = _stock.Products.SingleOrDefault(x => x.p.Id == p.Id);
            if (product == default)
            {
                _stock.Products.Add((p, quantity));
            }
            else
            {
                product.quantity += quantity;
            }
        }

        public void Add(List<(Product p, int quantity)> movements, DateTime date, string label)
        {
            foreach (var move in movements)
            {
                Add(move.p, move.quantity, date, label);

                var product = _stock.Products.SingleOrDefault(x => x.p.Id == move.p.Id);
                if (product == default)
                {
                    _stock.Products.Add((move.p, move.quantity));
                }
                else
                {
                    product.quantity += move.quantity;
                }
            }
        }

        public void SellProduct(Product p, int quantity, DateTime date, string label)
        {
            var move = new Movement { Date = date, Label = label, Products = { (p, quantity) } };
            _stock.Movements.Add(move);

            var product = _stock.Products.SingleOrDefault(x => x.p.Id == p.Id);
            if (product == default)
            {
                _stock.Products.Add((p, quantity));
            }
            else
            {
                product.quantity -= quantity;
            }
        }

        public List<(Product p, int quantity)> GetProductInStock()
        {
            return _stock.Products.Where(x => x.quantity > 0).Select(x => (x.p, x.quantity)).ToList();
        }


        const string inventaire = "inventaire";
        public int GetStock(Product p, DateTime date)
        {
            var movement = _stock.Movements.LastOrDefault(x => x.Date.Date <= date.Date && x.Products.Any(y => y.p.Id == p.Id));
            if (movement is null)
                return 0;

            if (movement.Label == inventaire)
                return movement.Products.Single(x => x.p.Id == p.Id).quantity;

            var quantity = 0;

            var movements = _stock.Movements.Where(x => x.Date.Date <= date.Date && x.Products.Any(y => y.p.Id == p.Id));

            foreach (var move in movements.OrderByDescending(x => x.Date))
            {
                quantity += move.Products.First(x => x.p.Id == p.Id).quantity;

                if (move.Label == inventaire)
                {
                    return quantity;
                }
            }

            if (quantity < 0) return 0;
            return quantity;
        }

        public int GetStock(Product p)
        {
            var product = _stock.Products.FirstOrDefault(x => x.p.Id == p.Id);

            if (product == default) return 0;
            return product.quantity;
        }

        public int GetAvailableProductsCountInStock()
        {
            return _stock.Products.Where(x => x.quantity > 0).Sum(x => x.quantity);
        }

        public int GetVariation(Product p, DateTime d1, DateTime d2)
        {
            var stock1 = GetStock(p, d1);
            var stock2 = GetStock(p, d2);

            if (d1 > d2) return stock1 - stock2;
            return stock2 - stock1;
        }

        public void SetStock(Product p, int quantity)
        {
            _stock.Movements.Add(new Movement { Date = DateTime.Now.Date, Label = inventaire, Products = { (p, quantity) } });
            var product = _stock.Products.SingleOrDefault(x => x.p.Id == p.Id);
            if (product == default)
            {
                _stock.Products.Add((p, quantity));
            }
            else
            {
                product.quantity = quantity;
            }
        }
    }
}
