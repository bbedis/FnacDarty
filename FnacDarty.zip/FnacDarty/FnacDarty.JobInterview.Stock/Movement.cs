﻿using System;
using System.Collections.Generic;

namespace FnacDarty.JobInterview.Stock
{
    public class Movement
    {
        public string Label { get; set; }
        public List<(Product p, int quantity)> Products { get; set; } = new List<(Product p, int quantity)>();
        public DateTime Date { get; set; }
    }
}
