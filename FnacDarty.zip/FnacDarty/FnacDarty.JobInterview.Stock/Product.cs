﻿using System;

namespace FnacDarty.JobInterview.Stock
{
    public class Product
    {
        public string Id { get; set; }
    }
}
